sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'softtek/TicketHist/model/formatter'
], function (Controller, JSONModel, Filter, FilterOperator, formatter) {
	"use strict";

	return Controller.extend("softtek.TicketHist.controller.historico", {

		formatter: formatter,

		onBeforeRendering: function (oEvent) {

			this.initFilterView();
			this.applyFilters();

		},

		applyFilters: function () {

			var aFilters = [];
			this.cargarFiltroPeriodo(aFilters, "Periodo");

			var oTable = this.getView().byId("Table");
			var oBinding = oTable.getBinding("items");
			oBinding.filter(aFilters);

		},

		cargarFiltroPeriodo: function (Filtros, Campo) {
			var oValor = sap.ui.core.Fragment.byId("FilterDialogFragment", Campo).getSelectedKey();

			var añoAct = new Date().getFullYear();
			var mesAct = new Date().getMonth() + 1;

			var lastday = new Date(añoAct, mesAct, 0);

			var monthCalc = new Date();
			monthCalc.setMonth(monthCalc.getMonth() - oValor);

			//var FecHasta = String(añoAct) + String(mesAct) + lastday.getDate();
			var FecHasta = new Date(añoAct, mesAct, lastday.getDate());

			//var FecDesde = String(monthCalc.getFullYear()) + String(monthCalc.getMonth() + 1) + "01";
			var FecDesde = new Date(monthCalc.getFullYear(), monthCalc.getMonth() + 1, 1);

			Filtros.push(new Filter("fechaFiltro", FilterOperator.BT, FecDesde, FecHasta));
		},

		cargarFiltro: function (Filtros, Campo) {
			var oValor = sap.ui.core.Fragment.byId("FilterDialogFragment", Campo).getSelectedKey();
			if (oValor !== "")
				Filtros.push(new Filter(Campo, FilterOperator.EQ, oValor));
		},

		handleMessagePopoverPress: function (oEvent) {

			if (!this.oMP) {
				this.createMessagePopover();
			}
			this.oMP.toggle(oEvent.getSource());

		},

		createMessagePopover: function () {

			var that = this;
			this.oMP = new sap.m.MessagePopover({
				activeTitlePress: function (oEvent) {
					var oItem = oEvent.getParameter("item"),
						oPage = that.oView.byId("messageHandlingPage"),
						oMessage = oItem.getBindingContext("message").getObject(),
						oControl = sap.ui.getCore().byId(oMessage.getControlId());

					if (oControl && oControl.getDomRef()) {
						oPage.scrollToElement(oControl.getDomRef(), 200, [0, -100]);
						setTimeout(function () {
							oControl.focus();
						}, 300);
					}
				},
				items: {
					path: "message>/",
					template: new sap.m.MessageItem({
						title: "{message>message}",
						subtitle: "{message>additionalText}",
						groupName: {
							parts: [{
								path: 'message>controlId'
							}],
							formatter: this.getGroupName
						},
						activeTitle: {
							parts: [{
								path: 'message>controlId'
							}],
							formatter: this.isPositionable
						},
						type: "{message>type}",
						description: "{message>message}"
					})
				}
			});

			this.oMP._oMessageView.setGroupItems(true);
			this.getView().byId("messageBtn").addDependent(this.oMP);

		},

		initFilterView: function () {
			if (!this._oViewSettingsDialog) {
				this._oViewSettingsDialog = sap.ui.xmlfragment("FilterDialogFragment", "softtek.TicketHist.view.filtros", this);
				this.getView().addDependent(this._oViewSettingsDialog);
				this._oFiltros = {
					Periodo: []
				};
				this.cargarPeriodo();
				this._oViewSettingsDialog.setModel(new sap.ui.model.json.JSONModel(this._oFiltros), "Filtros");
			}
		},

		onConfirm: function () {
			this._cargarFiltros = true;
			this.applyFilters();
			this._oViewSettingsDialog.close();

		},

		onClose: function () {
			this._oViewSettingsDialog.close();
		},

		cargarPeriodo: function () {

			this._oFiltros.Periodo = [{
				key: 3,
				value: "3 Meses"
			}, {
				key: 6,
				value: "6 Meses"
			}, {
				key: 12,
				value: "12 Meses"
			}];

			sap.ui.core.Fragment.byId("FilterDialogFragment", "Periodo").setSelectedKey(3);

		},

		cargartotales: function () {
			this.dibujarBar();

		},

		dibujarBar: function () {

			var oModel = this.getView().byId("Table").getBinding("items").getModel();
			var listadoTickets = this.getView().byId("Table").getBinding("items").aKeys;

			var oDatos = {
				Historico: [],
				iHistorico: []
			};

			if (listadoTickets instanceof Array) {

				listadoTickets.forEach(jQuery.proxy(function (element) {
					var oTicket = oModel.getProperty("/".concat([element], "/"));
					if (oTicket.periodo !== undefined) {
						var index = oDatos.iHistorico.indexOf(oTicket.periodo);
						if (index < 0) {

							oDatos.iHistorico.push(oTicket.periodo);
							oDatos.Historico.push({
								nombre: String(oTicket.periodo).substring(4, 6) + "." + String(oTicket.periodo).substring(0, 4),
								valor: oTicket.hsPeriodo,
								index: 1
							});
						} else {
							oDatos.Historico[index].valor = Number(oDatos.Historico[index].valor) + oTicket.hsPeriodo;
						}
					}
				}), this);
			}

			this.getView().byId("barTickets").setModel(new sap.ui.model.json.JSONModel(oDatos));
			/*this.getView().byId("barTickets").setModel(oModelo);*/
		},

		clearFilter: function () {
			this.setField("Periodo", "3");
			this.applyFilters();
		},

		setField: function (Campo, Valor) {
			sap.ui.core.Fragment.byId("FilterDialogFragment", Campo).setSelectedKey(Valor);
		},

		filtrar: function () {

			this._oViewSettingsDialog.open();

		}

	});
});